package pro;

public class ProfessorBean {
	private int p_no;
	private String p_pwd;
	private String p_name;
	private String p_jumin;
	private String p_tel;
	private String p_email;
	private String p_room;
	private int major_no;
	public int getP_no() {
		return p_no;
	}
	public void setP_no(int p_no) {
		this.p_no = p_no;
	}
	public String getP_pwd() {
		return p_pwd;
	}
	public void setP_pwd(String p_pwd) {
		this.p_pwd = p_pwd;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_jumin() {
		return p_jumin;
	}
	public void setP_jumin(String p_jumin) {
		this.p_jumin = p_jumin;
	}
	public String getP_tel() {
		return p_tel;
	}
	public void setP_tel(String p_tel) {
		this.p_tel = p_tel;
	}
	public String getP_email() {
		return p_email;
	}
	public void setP_email(String p_email) {
		this.p_email = p_email;
	}
	public String getP_room() {
		return p_room;
	}
	public void setP_room(String p_room) {
		this.p_room = p_room;
	}
	public int getMajor_no() {
		return major_no;
	}
	public void setMajor_no(int major_no) {
		this.major_no = major_no;
	}
	
	
}
