package lecture;

public class ScoreBean {
	private int student_s_no;
	private int professor_p_no;
	private int lecture_l_no;
	private String c_score;
	private int c_sem;
	private int c_year;
	
	public int getStudent_s_no() {
		return student_s_no;
	}
	public void setStudent_s_no(int student_s_no) {
		this.student_s_no = student_s_no;
	}
	public int getProfessor_p_no() {
		return professor_p_no;
	}
	public void setProfessor_p_no(int professor_p_no) {
		this.professor_p_no = professor_p_no;
	}
	public int getLecture_l_no() {
		return lecture_l_no;
	}
	public void setLecture_l_no(int lecture_l_no) {
		this.lecture_l_no = lecture_l_no;
	}
	public String getC_score() {
		return c_score;
	}
	public void setC_score(String c_score) {
		this.c_score = c_score;
	}
	public int getC_sem() {
		return c_sem;
	}
	public void setC_sem(int c_sem) {
		this.c_sem = c_sem;
	}
	public int getC_year() {
		return c_year;
	}
	public void setC_year(int c_year) {
		this.c_year = c_year;
	}
	
}
