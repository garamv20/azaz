package lecture;

public class LectureBean { //���� ���̺� �ִ°� ��������ϴ�.
	private int l_no;
	private String l_name;
	private int l_level;
	private int l_sem;
	private int l_unit;
	private int l_max;
	private String l_day;
	private int l_start;
	private int l_time;
	private String l_com;
	private int major_no;
	private int professor_p_no;
	
	public int getL_no() {
		return l_no;
	}
	public void setL_no(int l_no) {
		this.l_no = l_no;
	}
	public String getL_name() {
		return l_name;
	}
	public void setL_name(String l_name) {
		this.l_name = l_name;
	}
	public int getL_level() {
		return l_level;
	}
	public void setL_level(int l_level) {
		this.l_level = l_level;
	}
	public int getL_sem() {
		return l_sem;
	}
	public void setL_sem(int l_sem) {
		this.l_sem = l_sem;
	}
	public int getL_unit() {
		return l_unit;
	}
	public void setL_unit(int l_unit) {
		this.l_unit = l_unit;
	}
	public int getL_max() {
		return l_max;
	}
	public void setL_max(int l_max) {
		this.l_max = l_max;
	}
	public String getL_day() {
		return l_day;
	}
	public void setL_day(String l_day) {
		this.l_day = l_day;
	}
	public int getL_start() {
		return l_start;
	}
	public void setL_start(int l_start) {
		this.l_start = l_start;
	}
	public int getL_time() {
		return l_time;
	}
	public void setL_time(int l_time) {
		this.l_time = l_time;
	}
	public String getL_com() {
		return l_com;
	}
	public void setL_com(String l_com) {
		this.l_com = l_com;
	}
	public int getMajor_no() {
		return major_no;
	}
	public void setMajor_no(int major_no) {
		this.major_no = major_no;
	}
	public int getProfessor_p_no() {
		return professor_p_no;
	}
	public void setProfessor_p_no(int professor_p_no) {
		this.professor_p_no = professor_p_no;
	}
}
