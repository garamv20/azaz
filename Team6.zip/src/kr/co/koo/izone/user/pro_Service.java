package kr.co.koo.izone.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface pro_Service {
	
	void execute(HttpServletRequest request, HttpServletResponse response);
}
