function click_ok(){

	document.fr.submit();  //submit 할려고 만들었습니다.
}